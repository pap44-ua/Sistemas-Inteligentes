

class Restriccion:
    def __init__(self,coorX,varY,coorY):
        self.coorX=coorX
        self.varY=varY
        self.coorY=coorY