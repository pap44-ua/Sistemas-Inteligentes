

class Restriccion:
    def __init__(self,varY,coor):
        self.coor=coor
        self.varY=varY
       
    def getY(self):
        return self.varY
    
    def setY(self, varY):
        self.varY = varY
    
    